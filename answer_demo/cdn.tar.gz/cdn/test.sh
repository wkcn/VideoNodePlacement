./test ../../case_example/case0.txt out1.txt
