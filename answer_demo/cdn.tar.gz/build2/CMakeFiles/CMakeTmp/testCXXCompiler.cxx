#ifndef __cplusplus
# error "The CMAKE_CXX_COMPILER is set to a C compiler"
#endif
int main(){return 0;}
